
-- =========================
-- ADVANCED QUERIES
-- =========================

-- 1) Top 3 drivers by rating
SELECT name, rating FROM Driver ORDER BY rating DESC LIMIT 3;

-- 2) Revenue per month
SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, SUM(amount) AS revenue
FROM Payment
WHERE status='SUCCESS'
GROUP BY DATE_FORMAT(created_at, '%Y-%m');

-- 3) Most popular pickup locations
SELECT pickup, COUNT(*) AS rides
FROM Ride
GROUP BY pickup
ORDER BY rides DESC;

-- 4) Completed vs other statuses
SELECT status, COUNT(*) AS cnt
FROM Ride
GROUP BY status;

-- 5) Join: user with rides
SELECT u.name, r.ride_id, r.status
FROM User u
JOIN Ride r ON u.user_id = r.user_id;

-- 6) Subquery: drivers above avg rating
SELECT name, rating FROM Driver
WHERE rating > (SELECT AVG(rating) FROM Driver);

-- 7) Window function: rank drivers by rating
SELECT name, rating,
       RANK() OVER (ORDER BY rating DESC) AS rnk
FROM Driver;

-- 8) Active users (>=1 ride)
SELECT user_id, COUNT(*) AS rides
FROM Ride
GROUP BY user_id
HAVING COUNT(*) >= 1;

-- 9) Driver earnings total
SELECT d.name, SUM(p.amount) AS earnings
FROM Driver d
JOIN Ride r ON r.driver_id = d.driver_id
JOIN Payment p ON p.ride_id = r.ride_id AND p.status='SUCCESS'
GROUP BY d.driver_id;

-- 10) Avg distance by route
SELECT pickup, drop_location, AVG(distance_km) AS avg_km
FROM Ride
GROUP BY pickup, drop_location;
