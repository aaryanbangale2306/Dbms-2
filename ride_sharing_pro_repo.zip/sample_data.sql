
-- =========================
-- SAMPLE DATA
-- =========================

INSERT INTO User (name, phone, email) VALUES
('Aaryan','9999999999','a@gmail.com'),
('Rohit','9888888888','r@gmail.com'),
('Neha','9777777777','n@gmail.com'),
('Simran','9666666666','s@gmail.com'),
('Kunal','9555555555','k@gmail.com');

INSERT INTO Driver (name, phone, license_no, availability, rating) VALUES
('Raj','8888888888','LIC123',TRUE,4.5),
('Amit','8777777777','LIC124',TRUE,4.7),
('Ravi','8666666666','LIC125',TRUE,4.2),
('Suresh','8555555555','LIC126',TRUE,3.8),
('Vijay','8444444444','LIC127',TRUE,4.9);

INSERT INTO Vehicle (driver_id, type, number_plate) VALUES
(1,'Car','MH12AB1234'),
(2,'Bike','MH12BC2345'),
(3,'Car','MH12CD3456'),
(4,'Auto','MH12DE4567'),
(5,'Car','MH12EF5678');

INSERT INTO Ride (user_id, driver_id, pickup, drop_location, distance_km, status) VALUES
(1,1,'Pune','Mumbai',150,'BOOKED'),
(2,2,'Pune','Nashik',180,'BOOKED'),
(3,3,'Pune','Lonavala',65,'BOOKED'),
(4,4,'Pune','Satara',110,'BOOKED'),
(5,5,'Pune','Kolhapur',230,'BOOKED');

-- Payments (triggers will set status)
INSERT INTO Payment (ride_id, amount, method) VALUES
(1,2000,'UPI'),
(2,2400,'CARD'),
(3,900,'UPI'),
(4,1400,'CASH'),
(5,3200,'UPI');

INSERT INTO Rating (ride_id, user_rating, driver_rating, comments) VALUES
(1,5,4,'Good ride'),
(2,4,5,'Excellent'),
(3,3,4,'Average'),
(4,5,3,'Driver was late'),
(5,4,5,'Smooth ride');
