
-- =========================
-- TRIGGERS
-- =========================
DELIMITER //

-- 1) After a ride is booked, mark driver unavailable
CREATE TRIGGER trg_driver_unavailable
AFTER INSERT ON Ride
FOR EACH ROW
BEGIN
    UPDATE Driver SET availability = FALSE
    WHERE driver_id = NEW.driver_id;
END//

-- 2) Prevent booking if driver rating < 2.0
CREATE TRIGGER trg_block_low_rating
BEFORE INSERT ON Ride
FOR EACH ROW
BEGIN
    DECLARE r FLOAT;
    SELECT rating INTO r FROM Driver WHERE driver_id = NEW.driver_id;
    IF r < 2.0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Driver rating too low';
    END IF;
END//

-- 3) Validate payment amount
CREATE TRIGGER trg_validate_payment
BEFORE INSERT ON Payment
FOR EACH ROW
BEGIN
    IF NEW.amount IS NULL OR NEW.amount <= 0 THEN
        SET NEW.status = 'FAILED';
    ELSE
        SET NEW.status = 'SUCCESS';
    END IF;
END//

-- 4) Auto-complete ride after successful payment
CREATE TRIGGER trg_complete_ride
AFTER INSERT ON Payment
FOR EACH ROW
BEGIN
    IF NEW.status = 'SUCCESS' THEN
        UPDATE Ride SET status = 'COMPLETED'
        WHERE ride_id = NEW.ride_id;
    END IF;
END//

-- 5) Recompute driver rating after a new rating
CREATE TRIGGER trg_update_driver_rating
AFTER INSERT ON Rating
FOR EACH ROW
BEGIN
    UPDATE Driver d
    JOIN Ride r ON r.driver_id = d.driver_id
    SET d.rating = (
        SELECT AVG(rt.driver_rating)
        FROM Rating rt
        JOIN Ride rr ON rr.ride_id = rt.ride_id
        WHERE rr.driver_id = d.driver_id
    )
    WHERE r.ride_id = NEW.ride_id;
END//

DELIMITER ;
