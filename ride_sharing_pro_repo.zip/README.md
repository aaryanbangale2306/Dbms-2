# Ride Sharing Database System (Uber/Ola-like)

A complete DBMS college project with:
- ER → Relational schema (BCNF-ready)
- MySQL DDL, constraints
- Triggers (business rules)
- Stored Procedures (fare, reports)
- Sample data (seed)
- Advanced queries (analytics)
- Aesthetic frontend (glassmorphism dashboard)

## How to run (MySQL)
1. Create a DB: `CREATE DATABASE rideshare; USE rideshare;`
2. Run files in order:
   - schema.sql
   - triggers.sql
   - procedures.sql
   - sample_data.sql
   - queries.sql (for testing)
3. (Optional) Use a client (MySQL Workbench) to view results.

## Frontend (static demo)
Open `frontend/index.html` in a browser. It visualizes typical outputs.

## Notes
- Designed for clarity + viva explanation.
- Business rules enforced via triggers.
