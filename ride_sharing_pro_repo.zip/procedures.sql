
-- =========================
-- STORED PROCEDURES
-- =========================
DELIMITER //

-- Fare = base(10/km) + 20% surge
CREATE PROCEDURE CalculateFare(IN dist FLOAT, OUT fare DECIMAL(10,2))
BEGIN
    SET fare = dist * 10 * 1.2;
END//

-- Monthly ride summary for a user
CREATE PROCEDURE MonthlyUserReport(IN uid INT)
BEGIN
    SELECT DATE_FORMAT(created_at, '%Y-%m') AS month,
           COUNT(*) AS total_rides
    FROM Ride
    WHERE user_id = uid
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY month;
END//

-- Driver earnings per month
CREATE PROCEDURE DriverEarnings(IN did INT)
BEGIN
    SELECT DATE_FORMAT(p.created_at, '%Y-%m') AS month,
           SUM(p.amount) AS earnings
    FROM Payment p
    JOIN Ride r ON r.ride_id = p.ride_id
    WHERE r.driver_id = did AND p.status = 'SUCCESS'
    GROUP BY DATE_FORMAT(p.created_at, '%Y-%m')
    ORDER BY month;
END//

DELIMITER ;
