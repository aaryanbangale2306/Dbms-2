const ctx = document.getElementById('revChart');
new Chart(ctx, {
  type: 'line',
  data: {
    labels: ['Jan','Feb','Mar','Apr','May'],
    datasets: [{ label:'Revenue', data:[2000,2400,900,1400,3200] }]
  }
});
